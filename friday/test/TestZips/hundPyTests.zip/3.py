val = input()
print(val+1)
