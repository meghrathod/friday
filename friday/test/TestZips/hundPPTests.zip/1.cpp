#include <iostream>

using namespace std;

int main()
{
    int a;
    cin >> a;
    cout << a;

    return 0;
}