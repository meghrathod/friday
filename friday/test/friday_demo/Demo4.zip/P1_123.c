#include<stdio.h>

int main(){
  usleep(70000000); 
  return 0;
}
