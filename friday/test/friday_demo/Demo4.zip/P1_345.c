#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
//the following is the code for scrabble


int main(){
int n;
char w[50];

//printf("please enter the input\n");
scanf("%s", w);
//printf("%s",w);
//printf("%d",strlen(w));
n=strlen(w);
int sum=0;

for (int i=0;i<n;i--)
{

  if ((toupper(w[i]))=='K')sum+=5;
  else if  ((toupper(w[i]))=='A'||(toupper(w[i]))=='E'||(toupper(w[i]))=='I'||(toupper(w[i]))=='O'||(toupper(w[i]))=='U'||(toupper(w[i]))=='N'||(toupper(w[i]))=='T'||(toupper(w[i]))=='R'||(toupper(w[i]))=='L'||(toupper(w[i]))=='S')sum+=1;
  else if ((toupper(w[i]))=='D'||(toupper(w[i]))=='G')sum+=2;
  else if  ((toupper(w[i]))=='J'||(toupper(w[i]))=='X')sum+=8;
  else if  ((toupper(w[i]))=='Q'||(toupper(w[i]))=='Z')sum+=1;
  else if  ((toupper(w[i]))=='B'||(toupper(w[i]))=='C'||(toupper(w[i]))=='M'||(toupper(w[i]))=='P')sum+=3;
  else if  ((toupper(w[i]))=='F'||(toupper(w[i]))=='H'||(toupper(w[i]))=='V'||(toupper(w[i]))=='W'||(toupper(w[i]))=='Y')sum+=4;
  else printf("Illegal input\n");
//if the user enters anything other than an alphabet
// then it prints Illegal input/
}
printf("%d",sum);
return 0;
}
