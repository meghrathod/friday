//code to decode an encoded string
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
//to remove an unwanted character. in this case it is &
void removeChar(char *string, int c)
{

    int j, n = strlen(string);
    for (int i=j=0; i<n; i++)
       if (string[i] != c)
          string[j++] = string[i];

    string[j] = '\0';
}
int main()
{
     char string[50],ch;
     char temp;
     int i,shift=0;
    // printf("Enter the value of shift : ");
     scanf("%d",&shift);//takes value of shift
     if(shift>=1&&shift<=26)//so that it does not go outside the alphabetical set
     {
      // printf("Enter the coded string : ");
       scanf("%c",&temp);
       scanf("%[^\n]",string);//so that it can take spaces also

       for(i=0;string[i];i++)
       {
          if(string[i]>=97 && string[i]<=122)//if user enters small case string
          string[i] = string[i]-32;
       }

        //decode logic
        for(i=0;string[i];i++)
        {
          //int val = atoi(string[i]);
          // if shift-th ahead character preceed 'A'

       if(string[i] - shift < 65)
       {

        string[i] = 90-('A'-(string[i]-shift)-1);
        //to get it in range of alphabetical set

       }

       else

           string[i] = string[i] - shift;
         }

         //to decode spaces
      for ( i=0 ; i<strlen(string) ; i++)
        if (string[i]=='Q')
          string[i]=' ';
      removeChar(string,'&');//to access the removing of '&'
      printf("\n");
      printf("%s\n",string);
    }
  else
    printf("\ninvalid input");//if shift exceeds limit
    return 0;
}
