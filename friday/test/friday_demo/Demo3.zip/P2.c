#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>

int main()
{
  int shift_value = 0;
//  printf("\nPlease Enter the SHIFT VALUE :");
  scanf("%d",&shift_value);

  char code[100];
//  printf("Please Enter Coded Text : ");
  scanf("%[^\n]", code);

  //checking for right input
  int i=0;
  while(code[i]!='\0')
  {
    //printf("%d %c\n",i,code[i] );
    if((i+1)%7!=0)
    {
      if(!isalpha(code[i])&&!isupper(code[i]))
      {
        printf("INVALID SHIFT VALUE\n" );
        exit(0);
      }

    }
    else if ((i+1)%7==0&& i!=0)
    {
      if(code[i]!=' ')
      {
        printf("INVALID SHIFT VALUE\n" );
        exit(0);
      }
    }
    i++;
  }

  //removing space
  i = 0;
  while(code[i]!='\0')
  {
    if(code[i]==' ')
    {
      int j = i;
      while(code[j]!='\0')
      {
        code[j] = code[j+1];
        j++;
      }
    }
    i++;
  }

  //input of shift

  //adjusting shift value
  while(shift_value>25)
  {
    shift_value -=26;
  }
  //removing shift
  i=0;
  while(code[i]!='\0')
  {
    code[i]=code[i]-shift_value;
    if(code[i]<65)
    {
      code[i] = 'Z'-(65-code[i])+1;
    }
    i++;
  }
  //checking for last space and removing it
  if( code[i-1]=='Q'&& code[i-2]=='Q')
  {
    code[i-2] = '\0';
  }
  else
  {
    printf("INVALID SHIFT VALUE\n");
    exit(0);
  }
  // Replacing QQ with space

  int q_count =0;
  i =0;
  while(code[i]!='\0')
  {
      if(code[i]=='Q')
        q_count+=1;
      else
        q_count=0;
      if(q_count==2)
      {
        code[i-1] = ' ';
        int j = i;

        while(code[j]!='\0')
        {
          code[j]=code[j+1];
          j++;
        }
      }
      i++;
  }

  printf("%s\n",code);

  return 0;
}
