#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main()
{
  char word[50];
  int score = 0;
  int check_illegal =0;

  //printf("Please Enter your word : \n");
  scanf("%[^\n]", word);

  int i =0;
  while(word[i] != '\0' && check_illegal ==0)
  {
    //printf("%c\n",word[i]);
    switch ( (char) tolower(word[i]))
    {
      case 'a':
      case 'e':
      case 'i':
      case 'o':
      case 'u':
      case 'n':
      case 'l':
      case 'r':
      case 's':
      case 't': score +=1;
                break;
      case 'd':
      case 'g': score +=2;
                break;
      case 'b':
      case 'c':
      case 'p':
      case 'm': score +=3;
                break;
      case 'f':
      case 'h':
      case 'v':
      case 'w':
      case 'y': score +=4;
                break;
      case 'k': score +=5;
                break;
      case 'j':
      case 'x': score +=8;
                break;
      case 'q':
      case 'z': score +=10;
                break;
      default:  check_illegal =1;
                //printf("Invalid Input!!\n");
               //exit(0);
                break;

    }
    i++;
    //printf("%d\n",check_illegal);
  }
  // printf("%d\n",check_illegal);
  if(check_illegal==1)
  {
    printf("Invalid Input!!\n");
    exit(0);
  }
  printf("%d\n",score);

  return(0);
}
