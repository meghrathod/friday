#include<stdio.h>
#include<string.h>
#include<stdlib.h>
//the following is the code for a simple encryption system

int main()
{
int i,shift;
scanf("%d",&shift);
if(shift<0 || shift>26)
{
printf("INVALID SHIFT VALUE\n");
return 0;
}
char str[90];
//printf("INPUT: CODED TEXT");
//takikng input using gets()
gets(str);
//printf("\nSHIFT:  ");

for(i=0;i<str[i]!='\0';i++)
//just keep looping until you find the null zero
{
if(str[i]==' ')
{
continue;
}
if(str[i]-shift<65)
  str[i]=str[i]+26;
str[i]=str[i]-shift;
}
for(i=0;i<str[i]!='\0';i++)
{
if(str[i]==' ')
{
continue;
}
if(str[i]=='Q')
  {
    if(str[i+1]=='Q')
      {
        printf(" ");
        i=i+1;
        continue;
      }
  }//finding consequtive qq and then replacing it with SPACE

printf("%c",str[i]);
}//printing the decrypted message
return 0;
}
