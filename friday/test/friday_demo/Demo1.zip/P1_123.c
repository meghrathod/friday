//to calculate score of a word entered by the user
#include<stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
int main()
{
  int n,i=0;
  char word[50];//the word that user will enter
  char c;
  //printf("%s","enter the word\n");
  while(c != '\n')
  {
    if(c = getchar())
    {
      word[i] = c;
      i++;
    }
  }
  word[i]='\0';//to end it
  n=strlen(word);//to store the length of the string
  int sum=0;
  int k=0;
  for (int i=0;i<n-1;i++)
  {
    if(!isspace(word[i]))//as no space is allowed
    {
        //only upper case used, givinh values to alphabets
        if ((toupper(word[i]))=='K')
          sum+=5;
        else if  ((toupper(word[i])=='A') || (toupper(word[i])=='E')|| (toupper(word[i])=='I') || (toupper(word[i])=='O') || (toupper(word[i])=='U')|| (toupper(word[i])=='N') || (toupper(word[i])=='T')||(toupper(word[i])=='R')||(toupper(word[i])=='L')||(toupper(word[i])=='S'))
          sum+=1;
        else if ((toupper(word[i])=='D') || (toupper(word[i])=='G'))
          sum+=20;
        else if  ((toupper(word[i])=='J') || (toupper(word[i])=='X'))
          sum+=8;
        else if  ((toupper(word[i])=='Q') || (toupper(word[i])=='Z'))
          sum+=10;
        else if  ((toupper(word[i])=='B') || (toupper(word[i])=='C')|| (toupper(word[i])=='M')|| (toupper(word[i])=='P'))
          sum+=3;
        else if  ((toupper(word[i])=='F') || (toupper(word[i])=='H')|| (toupper(word[i])=='V')|| (toupper(word[i])=='W')|| (toupper(word[i])=='Y'))
          sum+=4;
      }
      else
      {
        sum*=0;//as it has space so it is wrong input, and we get 0
        break;
      }

    }
  if(sum!=0)
  {
  //  printf("%s","\nthe score for this word is\n");
    printf("%d",sum);//to get the value
  }
  else
  {
    printf("Illegal Input");
    //as a non appropriate word with space or other characters is entered
  }

  return 0;
}
