#include<stdio.h>

int main()
{
    int test;
    test = 1;
    //scanf("%d",&test);
    printf("%d",test);
}