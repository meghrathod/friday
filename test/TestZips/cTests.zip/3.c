#include<stdio.h>

int main()
{
    int test;
    scanf("%d",&test);
    printf("%d",test);
}