#include <iostream>

using namespace std;

int main()
{
    int a;
    cin >> a;
    cout << '1';

    return 0;
}