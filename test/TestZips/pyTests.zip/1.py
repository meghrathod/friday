val = input()
print(val)
