import java.util.Scanner;
class Sums
{
    // Your program begins with a call to main().
    // Prints "Hello, World" to the terminal window.
    public static void main(String args[])
    {
        Scanner myObj = new Scanner(System.in);
        int a = myObj.nextInt();
        System.out.println(a);
    }
}