import java.util.Scanner;

class Sums
{
    public static void main(String args[])
    {
        Scanner myObj = new Scanner(System.in);
        int a = myObj.nextInt();
        System.out.println(a+1);
    }    
}
